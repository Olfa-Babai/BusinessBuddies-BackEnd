package tn.esprit.spring.entities;

public enum Processing {
Loanding,Processed,NotYet
}
