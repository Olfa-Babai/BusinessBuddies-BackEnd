package tn.esprit.spring.entities;

public enum invitationStatus {
	PENDING, REFUSED, ACCEPTED
}
