package tn.esprit.spring.entities;

public enum FeedbackType {
OnService, OnEntreprise, OnEmployee
}
