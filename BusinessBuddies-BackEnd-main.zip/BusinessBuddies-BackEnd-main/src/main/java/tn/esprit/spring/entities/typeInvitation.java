package tn.esprit.spring.entities;

public enum typeInvitation {
	TRIP,COMPANY
}
