package tn.esprit.spring.services;

public interface IEmailServiceCommunication {

	//void sendSimpleEmail(String toEmail,String body,String subject);
	
}
