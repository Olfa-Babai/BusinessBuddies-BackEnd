package tn.esprit.spring.entities;

public enum Theme {
Economics,
Technology,
Fashion,
Politics
}
