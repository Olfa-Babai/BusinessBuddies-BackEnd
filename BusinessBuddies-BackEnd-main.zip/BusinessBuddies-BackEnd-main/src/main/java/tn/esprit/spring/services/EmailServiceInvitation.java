package tn.esprit.spring.services;

public interface EmailServiceInvitation {

}
