package tn.esprit.spring.entities;

public enum TypeLike {
like, dislike
}
