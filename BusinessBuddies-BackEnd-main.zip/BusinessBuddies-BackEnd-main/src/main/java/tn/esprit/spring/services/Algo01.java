package tn.esprit.spring.services;

public interface Algo01 {

}
