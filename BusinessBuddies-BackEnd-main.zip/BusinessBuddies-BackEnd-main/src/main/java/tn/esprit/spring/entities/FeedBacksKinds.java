package tn.esprit.spring.entities;

public enum FeedBacksKinds {
evaluatif , actif 
}
