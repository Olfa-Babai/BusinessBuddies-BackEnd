package tn.esprit.spring.services;

public class Algo01Imp {

}
