package tn.esprit.spring.entities;

public enum Status {
JOIN,MESSAGE,LEAVE
}
