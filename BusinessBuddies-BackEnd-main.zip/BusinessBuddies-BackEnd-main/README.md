# BusinessBuddies-BackEnd
This is a backend section of our web application "Business Buddies" developped by "DevHolics" 